function validate()
{
    var username=document.getElementById("username").value;
    var password=document.getElementById("password").value;
    if(username == "pri1234" && password == "pri")
    {
        alert("Login Successful");
        window.open("login2.html");
    }
    else
    {
        alert("Login Failed");
        window.open("first.html");
    }
}